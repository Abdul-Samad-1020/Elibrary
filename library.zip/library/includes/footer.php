   <section class="footer-section">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    &copy; E-Library System by <a href="https://www.linkedin.com/in/abdulsamadmughal/" target="_blank"><strong>Abdul Samad</a></a> 
                    <sub></sub>
                </div>

            </div>
        </div>
    </section>